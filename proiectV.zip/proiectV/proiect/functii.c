#include <inavr.h>
#include <iom16.h>
extern unsigned char stare_automat, intrare_automat_edge, intrare_automat_ovf;
extern unsigned short canal1, canal2, canal3, canal4, canal5, canal6, canal7, canal8, valoare_timer;
void initializare(){
  OCR1A = 10000;
  DDRD = (1<<PD5)|(0<<PD6);
  TCCR1A = (1<<COM1A0);
  TCCR1B = (1<<CS10)|(1<<WGM12);
  TIMSK = (1<<OCIE1A)|(1<<TICIE1);
  __enable_interrupt();
}

__interrupt void intrerupere_timer1_compar(void){
	intrare_automat_ovf = 1;
}

__interrupt void intrerupere_timer1_input(void){
	valoare_timer = TCNT1;
    TCNT1=0;
	intrare_automat_edge = 1;
}
void state_update(){
  switch(stare_automat){
  case 0:{//caz overflow
    if(intrare_automat_edge){
      stare_automat=1;
      intrare_automat_edge=0;
	  intrare_automat_ovf = 0;
    }
	//TCNT1=0;//de testat
    break;}
  case 1:{//canalul 1
    if(intrare_automat_edge){
      canal1=valoare_timer;
      stare_automat=2;
      intrare_automat_edge=0;
    }
    else if(intrare_automat_ovf){
      stare_automat=9;
      intrare_automat_ovf=0;
    }
    break;}
  case 2:{//canalul 2
    if(intrare_automat_edge){
      canal2=valoare_timer;
      stare_automat=3;
      intrare_automat_edge=0;
    }
    else if(intrare_automat_ovf){
      stare_automat=9;
      intrare_automat_ovf=0;
    }
    break;}
  case 3:{//canalul 3
    if(intrare_automat_edge){
      canal3=valoare_timer;
      stare_automat=4;
      intrare_automat_edge=0;
    }
    else if(intrare_automat_ovf){
      stare_automat=9;
      intrare_automat_ovf=0;
    }
    break;}
  case 4:{//canalul 4
    if(intrare_automat_edge){
      canal4=valoare_timer;
      stare_automat=5;
      intrare_automat_edge=0;
    }
    else if(intrare_automat_ovf){
      stare_automat=9;
      intrare_automat_ovf=0;
    }
    break;}
  case 5:{//canalul 5
    if(intrare_automat_edge){
      canal5=valoare_timer;
      stare_automat=6;
      intrare_automat_edge=0;
    }
    else if(intrare_automat_ovf){
      stare_automat=9;
      intrare_automat_ovf=0;
    }
    break;}
  case 6:{//canalul 6
    if(intrare_automat_edge){
      canal6=valoare_timer;
      stare_automat=7;
      intrare_automat_edge=0;
    }
    else if(intrare_automat_ovf){
      stare_automat=9;
      intrare_automat_ovf=0;
    }
    break;}
  case 7:{//canalul 7
    if(intrare_automat_edge){
      canal7=valoare_timer;
      stare_automat=8;
      intrare_automat_edge=0;
    }
    else if(intrare_automat_ovf){
      stare_automat=9;
      intrare_automat_ovf=0;
    }
    break;}
  case 8:{//canalul 8
    if(intrare_automat_edge){
      canal8=valoare_timer;
      stare_automat=0;
      intrare_automat_edge=0;
    }
    else if(intrare_automat_ovf){
      stare_automat=9;
      intrare_automat_ovf=0;
    }
    break;}
  case 9:{//reset
    if(intrare_automat_ovf){
      stare_automat = 0;
      intrare_automat_ovf=0;
	  intrare_automat_edge=0;
    }
    break;}  
  }
}
