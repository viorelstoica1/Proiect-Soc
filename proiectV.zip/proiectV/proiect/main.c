#include <ioavr.h>
extern void get_port(void);/* Prototipul func?iei ASM */
void main(void)
{
  DDRD = 0x00;/* Ini?ializeaz? porturile de I/O*/
  DDRB = 0xFF;
  while(1)/* Bucla infinit?*/ 
  {
    get_port();/* Apelul func?iei scrise ?n ASM */ 
  }
}