//#ifndef __IAR_SYSTEMS_ASM__
#ifndef FUNCTII_H
#define FUNCTII_H
unsigned char max_val;
unsigned char rand();
#endif
//#endif