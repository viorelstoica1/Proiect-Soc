#include <inavr.h> 
#include <iom16.h>

unsigned char intrare_automat=0;
unsigned short iesire_automat=0;
unsigned char stare_automat=0;

extern void fac0(void);/* Prototipul functiei ASM */
extern void c_intrerupere();
extern void ext_intrerupere();
void main(void)
{
  DDRD = 0x00;/* Initializeaza porturile de I/O*/
  DDRB = 0xFF;
  fac0();
 
  __enable_interrupt();
  while(1)/* Bucla infinit?*/ 
  {
    switch(stare_automat)
    {
    case 0:
      {
        if(intrare_automat==1)
       {
        stare_automat=1;
        TCCR1B = (1<<CS12)|(1<<CS10)|(1<<ICNC1)|(0<<ICES1);
        TCNT1=0;
       }
      break;
      }
      
      
    case 1:
      {
        if(intrare_automat==0)
        {
          
          stare_automat=0;
          unsigned short timp_curent= TCNT1;
          if(timp_curent>=10)
          {
            iesire_automat=timp_curent;
            int abc=0;
          }
          else
          {
            iesire_automat=0;
          }
          //iesire_automat=TCNT1;
          TCCR1B = (1<<CS12)|(1<<CS10)|(1<<ICNC1)|(1<<ICES1);
        }
        
     break;
     
      }
    }
      ;
  }
}