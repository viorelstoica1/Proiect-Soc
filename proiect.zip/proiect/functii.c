unsigned char max_val=1;

unsigned char rand(){
  static unsigned char paritate = 0;
  if(paritate++%2==0){
    return max_val+1;
  }
  return max_val-1;
}

void simplu(){
  max_val++;
}

void mediu(unsigned char increment){
  max_val+=increment;
}

unsigned char greu(unsigned char increment){
  max_val+=increment;
  return max_val-increment;
}