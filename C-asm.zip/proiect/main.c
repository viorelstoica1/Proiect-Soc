#include <inavr.h> 
#include <iom16.h>

extern void fac0(void);/* Prototipul functiei ASM */
extern void c_intrerupere();
extern void ext_intrerupere();
void main(void)
{
  DDRD = 0x00;/* Initializeaza porturile de I/O*/
  DDRB = 0xFF;
  fac0();
 
  __enable_interrupt();
  while(1)/* Bucla infinit?*/ 
  {
    ;/* Apelul functiei scrise in ASM */ 
  }
}